'use client'

// import { SiCoffeescript } from 'react-icons/si'
import { IoCreate, IoReturnDownBack } from 'react-icons/io5'
import { useState } from 'react'
import { motion } from 'framer-motion'
import Image from 'next/image'

interface HeaderProps {
    onCreateTask: () => void
    onToggleEdit: () => void
  }

const Header = ({ 
    onCreateTask,
    onToggleEdit,
    }: HeaderProps) => {
  const [isOpen, setIsOpen] = useState(false)

  const toggleInstruments = () => {
    onToggleEdit()
    setIsOpen(!isOpen)
  }

  const styleMain = {
    background:
      'linear-gradient(90deg,rgba(255, 190, 146, 0.5) 0%, rgba(255, 182, 167, 0.5) 49%, rgba(255, 172, 147, 0.5) 100%)',
    boxShadow: '0 4px 70px rgba(0, 0, 0, 0.079)',
    borderRadius: '100px',
    backdropFilter: 'blur(20px)',
  }

  return (
    <header className="text-[#130a07] font-bold">
      {!isOpen ? (
        <div
          onClick={toggleInstruments}
          className="cup_transition flex justify-center items-center bg-white/20 text-white py-6 px-16 w-fit mx-auto mt-6 rounded-full shadow-lg backdrop-blur-md hover:shadow-2xl transition-transform duration-500 ease-in-out cursor-pointer hover:scale-105"
          style={styleMain}
        >
          <motion.div
            className="flex items-center text-4xl font-extrabold"
            initial={{ opacity: 0, scale: 0.8, y: -5 }}
            transition={{ duration: 0.5, type: 'spring' }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
          >
            <span>Start a </span>
            <Image
              src="/navigation/cup.svg"
              alt="cup"
              width={12}
              height={12}
              className="w-14 h-14 mx-4 mb-[12px]"
            />
            <span>session</span>
          </motion.div>
        </div>
      ) : (
        <div className="flex justify-between w-fit mx-auto mt-6">
          <motion.div
            className="cup_transition flex items-center text-2xl font-semibold"
            initial={{ opacity: 0.5, scaleY: 0, y: -5 }}
            transition={{ duration: 0.5, type: 'spring' }}
            animate={{ opacity: 1, scaleY: 1, y: 0 }}
          >
            <nav>
              <ul className="flex space-x-8">
                <li onClick={onCreateTask} className="text-white hover:text-gray-300 transition duration-300 p-4 rounded-full hover:scale-105 cursor-pointer" style={styleMain}>
                  <IoCreate className="w-8 h-8 f-bold rounded" />
                </li>
                {/* <li className="text-white hover:text-gray-300 transition duration-300 p-4 rounded-full hover:scale-105 cursor-pointer" style={styleMain}>
                  <IoSettings className="w-8 h-8 f-bold rounded" />
                </li> */}
                {/* <li className="text-white hover:text-gray-300 transition duration-300 p-4 rounded-full hover:scale-105 cursor-pointer" style={styleMain}>
                  <SiCoffeescript className="w-8 h-8 f-bold rounded" />
                </li> */}
                <li onClick={toggleInstruments} className="text-white hover:text-gray-300 transition duration-300 p-4 rounded-full hover:scale-105 cursor-pointer" style={styleMain}>
                  <IoReturnDownBack className="w-8 h-8 f-bold rounded" />
                </li>
              </ul>
            </nav>
          </motion.div>
        </div>
      )}
    </header>
  )
}

export default Header
