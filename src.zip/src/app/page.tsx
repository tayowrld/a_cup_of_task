'use client'

import Header from '@/components/layout/header'
import Workspace from '@/components/workflow/workspace'
import { Task } from '@/types/types'
import { getTasks, saveTasks } from '@/lib/db'
import { useEffect, useState } from 'react'

export default function Home() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [isEditingMode, setIsEditingMode] = useState(false)

  useEffect(() => {
    getTasks().then((stored) => {
      if (stored && stored.length) setTasks(stored)
    })
  }, [])

  const handleToggleEditingMode = () => {
    setIsEditingMode((prev) => !prev)
  }

  const handleRenameTask = (id: number, newName: string) => {
    const updated = tasks.map(task =>
      task.id === id ? { ...task, name: newName } : task
    )
    updateTasks(updated)
  }

  const updateTasks = (updated: Task[]) => {
    setTasks(updated)
    saveTasks(updated)
    console.log('Saving tasks:', updated)
  }

  const handlePrioritySwitch = (id: number, priority: { value: string, color: string }) => {
    const updated = tasks.map((task) =>
      task.id === id ? { ...task, priority } : task
    )
    updateTasks(updated)
  }

  const handleStatusSwitch = (id: number, status: { value: string, color: string }) => {
    const updated = tasks.map((task) =>
      task.id === id ? { ...task, status } : task
    )
    updateTasks(updated)
  }

  const handleCreateTask = (name: string, date: string) => {
    const newTask: Task = {
      id: tasks.length,
      name,
      date,
      priority: undefined,
      status: {value: 'Actual', color: 'amber'},
    }
    const updated = [...tasks, newTask]
    updateTasks(updated)
  }

  return (
    <>
      <Header 
        onCreateTask={() => handleCreateTask('Новая задача', new Date().toISOString().split('T')[0])}
        onToggleEdit={handleToggleEditingMode}
      />
      <Workspace
        tasks={tasks}
        isEditing={isEditingMode}
        onRenameTask={handleRenameTask}
        onDeleteTask={(id) => {
          const updated = tasks.filter(task => task.id !== id)
          updateTasks(updated)
        }}
        onPrioritySwitch={handlePrioritySwitch}
        onStatusSwitch={handleStatusSwitch}
      />
    </>
  )
}
