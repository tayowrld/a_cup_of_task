import { get, set, del } from 'idb-keyval'
import { Task } from '@/types/types';

export const getTasks = () => get('tasks')
export const saveTasks = (tasks: Task[]) => set('tasks', tasks)
export const clearTasks = () => del('tasks')