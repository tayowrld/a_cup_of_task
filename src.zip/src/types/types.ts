export interface Task {
    id: number;
    name: string;
    date: string;
    priority?: { value: string, color: string };
    status?: { value: string, color: string };
}